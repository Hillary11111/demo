import { Block } from "./block.js"
import { CoinbaseTransaction } from "./transaction.js"
import { hashJSON } from "./crypto.js"

export const BLOCK_REWARD = 50

/**
 * Account-model chain: state is derived by replaying every block, which keeps
 * validation rules simple and easy to audit.
 */
export class Blockchain {
  constructor({ difficulty = 2 } = {}) {
    this.difficulty = difficulty
    this.chain = [Block.genesis()]
  }

  get height() {
    return this.chain.length
  }

  get latestBlock() {
    return this.chain[this.chain.length - 1]
  }

  mineBlock(transactions = [], minerAddress = null) {
    const height = this.height
    const txs = [...transactions]

    if (minerAddress) {
      txs.unshift(new CoinbaseTransaction({ to: minerAddress, amount: BLOCK_REWARD, height }))
    }

    const block = new Block({
      index: height,
      timestamp: Date.now(),
      previousHash: this.latestBlock.hash,
      transactions: txs,
    })

    block.mine(this.difficulty)
    this.addBlock(block)
    return block
  }

  addBlock(block) {
    const expectedIndex = this.height
    const seen = new Set()
    for (const existing of this.chain) for (const tx of existing.transactions) seen.add(tx.id)
    for (const tx of block.transactions) if (seen.has(tx.id)) return false

    if (!block.isValid(this.difficulty)) return false
    if (block.index !== expectedIndex) return false
    if (block.previousHash !== this.latestBlock.hash) return false

    this.chain.push(block)
    return true
  }

  /** Validates the entire chain, including every stored hash and proof-of-work. */
  isValidChain() {
    for (let i = 1; i < this.chain.length; i++) {
      const current = this.chain[i]
      const previous = this.chain[i - 1]

      if (!current.isValid(this.difficulty)) return false
      if (current.previousHash !== previous.hash) return false
      if (current.index !== previous.index + 1) return false
    }

    const ids = new Set()
    for (const block of this.chain) {
      for (const tx of block.transactions) {
        if (tx instanceof CoinbaseTransaction) continue
        if (ids.has(tx.id)) return false
        if (!tx.isValid()) return false
        ids.add(tx.id)
      }
    }
    return true
  }

  /** Replays the chain to compute one address' balance. */
  getBalance(address) {
    let balance = 0
    for (const block of this.chain) {
      for (const tx of block.transactions) {
        if (tx.from === address) balance -= tx.amount
        if (tx.to === address) balance += tx.amount
      }
    }
    return balance
  }

  /** Spendable balance: everything received minus what is already committed to the mempool. */
  getSpendableBalance(address, mempool = []) {
    let pendingOut = 0
    for (const tx of mempool) if (tx.from === address) pendingOut += tx.amount
    return this.getBalance(address) - pendingOut
  }

  getTransactionsFor(address) {
    return this.chain.flatMap((block) => block.transactions.filter((tx) => tx.from === address || tx.to === address))
  }

  fingerprint() {
    return hashJSON(this.chain.map((b) => b.hash))
  }

  toJSON() {
    return { difficulty: this.difficulty, chain: this.chain.map((b) => b.toJSON()) }
  }

  static fromJSON(obj) {
    const bc = new Blockchain({ difficulty: obj.difficulty ?? 2 })
    bc.chain = obj.chain.map((b) => Block.fromObject(b))
    return bc
  }
}