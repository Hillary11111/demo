import {
  createHash,
  generateKeyPairSync,
  createPrivateKey,
  createPublicKey,
  createSign,
  createVerify,
} from "node:crypto"

/**
 * Recursively sorts object keys so that serialization is deterministic.
 * Hashing must never depend on JavaScript property insertion order.
 */
export function stableStringify(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value)
  if (Array.isArray(value)) return "[" + value.map(stableStringify).join(",") + "]"
  const keys = Object.keys(value).sort()
  return "{" + keys.map((k) => JSON.stringify(k) + ":" + stableStringify(value[k])).join(",") + "}"
}

export function sha256(data) {
  return createHash("sha256").update(data).digest("hex")
}

export function hashJSON(value) {
  return sha256(stableStringify(value))
}

/**
 * Standard binary Merkle tree. An empty list hashes to the empty digest so a
 * block with no transactions still produces a deterministic root.
 */
export function merkleRoot(hashes) {
  if (hashes.length === 0) return sha256("")
  if (hashes.length === 1) return hashes[0]

  const level = [...hashes]
  while (level.length > 1) {
    const next = []
    for (let i = 0; i < level.length; i += 2) {
      const left = level[i]
      const right = level[i + 1] ?? left
      next.push(sha256(left + right))
    }
    level.length = 0
    level.push(...next)
  }
  return level[0]
}

/** secp256k1 keypair, the same curve Bitcoin and Ethereum use. */
export function generateKeyPair() {
  const { privateKey, publicKey } = generateKeyPairSync("ec", { namedCurve: "secp256k1" })
  return {
    privateKey: privateKey.export({ type: "pkcs8", format: "der" }).toString("base64"),
    publicKey: publicKey.export({ type: "spki", format: "der" }).toString("base64"),
  }
}

export function sign(privateKeyB64, payload) {
  const key = createPrivateKey({
    key: Buffer.from(privateKeyB64, "base64"),
    format: "der",
    type: "pkcs8",
  })
  const signer = createSign("SHA256")
  signer.update(payload)
  return signer.sign(key).toString("base64")
}

export function verify(publicKeyB64, payload, signatureB64) {
  try {
    const key = createPublicKey({
      key: Buffer.from(publicKeyB64, "base64"),
      format: "der",
      type: "spki",
    })
    const verifier = createVerify("SHA256")
    verifier.update(payload)
    return verifier.verify(key, Buffer.from(signatureB64, "base64"))
  } catch {
    return false
  }
}

/** Address = first 20 bytes of sha256(publicKey), hex encoded. */
export function addressFromPublicKey(publicKeyB64) {
  return "0x" + sha256(publicKeyB64).slice(0, 40)
}