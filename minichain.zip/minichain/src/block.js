import { hashJSON, merkleRoot } from "./crypto.js"
import { Transaction, CoinbaseTransaction } from "./transaction.js"

export const GENESIS_DATA = { message: "minichain genesis block" }

/**
 * A block commits to its transactions through a Merkle root, so the header
 * hash stays small no matter how many transactions the block carries.
 */
export class Block {
  constructor({ index, timestamp, previousHash, transactions = [], nonce = 0, hash = null, data = GENESIS_DATA }) {
    this.index = index
    this.timestamp = timestamp
    this.previousHash = previousHash
    this.transactions = transactions
    this.data = data
    this.nonce = nonce
    this.hash = hash
  }

  static genesis() {
    const block = new Block({
      index: 0,
      timestamp: 1700000000000,
      previousHash: "0".repeat(64),
      data: GENESIS_DATA,
    })
    return block.mine(2)
  }

  header() {
    return {
      index: this.index,
      timestamp: this.timestamp,
      previousHash: this.previousHash,
      merkleRoot: this.merkleRoot(),
      nonce: this.nonce,
    }
  }

  merkleRoot() {
    return merkleRoot(this.transactions.map((tx) => tx.id ?? hashJSON(tx)))
  }

  calculateHash() {
    return hashJSON(this.header())
  }

  /** Proof-of-work: grind `nonce` until the header hash has N leading zeros. */
  mine(difficulty) {
    this.nonce = 0
    while (!this.hashMeetsDifficulty(difficulty)) this.nonce++
    this.hash = this.calculateHash()
    return this
  }

  hashMeetsDifficulty(difficulty = 2) {
    return this.calculateHash().startsWith("0".repeat(difficulty))
  }

  /** Re-derives the hash so a mutated field can never pass validation. */
  recomputeHash() {
    return this.calculateHash()
  }

  isValid(difficulty = 2) {
    if (this.hash !== this.recomputeHash()) return false
    if (!this.hashMeetsDifficulty(difficulty)) return false
    return this.transactions.every((tx) => tx.isValid())
  }

  toJSON() {
    return {
      index: this.index,
      timestamp: this.timestamp,
      previousHash: this.previousHash,
      data: this.data,
      nonce: this.nonce,
      hash: this.hash,
      merkleRoot: this.merkleRoot(),
      transactions: this.transactions.map((tx) => tx.toJSON?.() ?? tx),
    }
  }

  static fromObject(obj) {
    return new Block({
      index: obj.index,
      timestamp: obj.timestamp,
      previousHash: obj.previousHash,
      data: obj.data,
      nonce: obj.nonce,
      hash: obj.hash,
      transactions: (obj.transactions ?? []).map((tx) =>
        tx.coinbase ? CoinbaseTransaction.fromObject(tx) : Transaction.fromObject(tx),
      ),
    })
  }
}