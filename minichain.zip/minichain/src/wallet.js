import { generateKeyPair, addressFromPublicKey, sign } from "./crypto.js"
import { Blockchain } from "./blockchain.js"
import { Mempool } from "./mempool.js"
import { Transaction } from "./transaction.js"

/** A secp256k1 keypair plus the derived address and a signing helper. */
export class Wallet {
  constructor({ privateKey, publicKey } = generateKeyPair()) {
    this.privateKey = privateKey
    this.publicKey = publicKey
    this.address = addressFromPublicKey(publicKey)
  }

  sign(payload) {
    return sign(this.privateKey, payload)
  }

  /**
   * Builds and signs a transfer. Throws when the balance is too low so an
   * unfunded transaction never reaches the mempool.
   */
  createTransaction(recipient, amount, mempool = new Mempool()) {
    if (typeof recipient !== "string" || !/^0x[0-9a-f]{40}$/.test(recipient)) {
      throw new Error(`invalid recipient address: ${recipient}`)
    }
    if (!Number.isInteger(amount) || amount <= 0) {
      throw new Error("amount must be a positive integer")
    }

    const chain = Blockchain.load()
    const spendable = chain.getSpendableBalance(this.address, mempool.transactions)
    if (spendable < amount) {
      throw new Error(`insufficient funds: balance ${spendable}, need ${amount}`)
    }

    const tx = new Transaction({ from: this.address, to: recipient, amount })
    tx.sign(this)
    return tx
  }

  toJSON() {
    return { privateKey: this.privateKey, publicKey: this.publicKey, address: this.address }
  }

  static fromJSON(obj) {
    return new Wallet(obj)
  }
}