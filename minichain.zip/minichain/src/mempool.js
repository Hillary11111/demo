/** Pending transactions waiting to be included in the next block. */
import { Transaction, CoinbaseTransaction } from "./transaction.js"

export class Mempool {
  constructor() {
    this.transactions = []
  }

  add(tx) {
    if (!tx.isValid()) return false
    if (this.transactions.some((t) => t.id === tx.id)) return false
    this.transactions.push(tx)
    return true
  }

  /** Drops transactions that are invalid or that the sender can no longer afford. */
  validTransactions(blockchain) {
    return this.transactions.filter((tx) => {
      if (!tx.isValid()) return false
      return blockchain.getSpendableBalance(tx.from, this.transactions) >= tx.amount
    })
  }

  has(id) {
    return this.transactions.some((t) => t.id === id)
  }

  clear() {
    this.transactions = []
  }

  toJSON() {
    return this.transactions.map((tx) => tx.toJSON?.() ?? tx)
  }

  static fromJSON(arr = []) {
    const pool = new Mempool()
    pool.transactions = arr.map((tx) =>
      tx.coinbase ? CoinbaseTransaction.fromObject(tx) : Transaction.fromObject(tx),
    )
    return pool
  }
}