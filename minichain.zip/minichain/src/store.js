import { existsSync, mkdirSync, readFileSync, writeFileSync, readdirSync } from "node:fs"
import { join, dirname } from "node:path"
import { fileURLToPath } from "node:url"
import { Blockchain } from "./blockchain.js"
import { Mempool } from "./mempool.js"
import { Wallet } from "./wallet.js"

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..")
const DATA_DIR = join(ROOT, "data")
const CHAIN_FILE = join(DATA_DIR, "chain.json")
const MEMPOOL_FILE = join(DATA_DIR, "mempool.json")
const WALLET_DIR = join(DATA_DIR, "wallets")

function ensureDirs() {
  mkdirSync(DATA_DIR, { recursive: true })
  mkdirSync(WALLET_DIR, { recursive: true })
}

function readJSON(path, fallback) {
  if (!existsSync(path)) return fallback
  try {
    return JSON.parse(readFileSync(path, "utf8"))
  } catch {
    return fallback
  }
}

function writeJSON(path, value) {
  ensureDirs()
  writeFileSync(path, JSON.stringify(value, null, 2))
}

/** The chain is the single source of truth; every helper loads it fresh. */
Blockchain.load = function load() {
  const raw = readJSON(CHAIN_FILE, null)
  if (!raw) {
    const bc = new Blockchain()
    Blockchain.save(bc)
    return bc
  }
  return Blockchain.fromJSON(raw)
}

Blockchain.save = function save(bc) {
  writeJSON(CHAIN_FILE, bc.toJSON())
}

Blockchain.reset = function reset() {
  const bc = new Blockchain()
  Blockchain.save(bc)
  writeJSON(MEMPOOL_FILE, [])
  return bc
}

export function loadMempool() {
  return Mempool.fromJSON(readJSON(MEMPOOL_FILE, []))
}

export function saveMempool(pool) {
  writeJSON(MEMPOOL_FILE, pool.toJSON())
}

export function listWallets() {
  ensureDirs()
  return readdirSync(WALLET_DIR)
    .filter((f) => f.endsWith(".json"))
    .map((f) => JSON.parse(readFileSync(join(WALLET_DIR, f), "utf8")))
    .map((obj) => Wallet.fromJSON(obj))
}

export function loadWallet(address) {
  const path = join(WALLET_DIR, `${address}.json`)
  if (!existsSync(path)) throw new Error(`wallet not found: ${address}`)
  return Wallet.fromJSON(readJSON(path, null))
}

export function saveWallet(wallet) {
  ensureDirs()
  writeJSON(join(WALLET_DIR, `${wallet.address}.json`), wallet.toJSON())
}

export { ROOT, DATA_DIR }