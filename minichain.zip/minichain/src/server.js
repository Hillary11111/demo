import { createServer } from "node:http"
import { readFile } from "node:fs/promises"
import { dirname } from "node:path"
import { join } from "node:path"
import { fileURLToPath } from "node:url"
import { Blockchain } from "./blockchain.js"
import { loadMempool, listWallets, loadWallet, saveWallet, saveMempool } from "./store.js"
import { Wallet } from "./wallet.js"

function sendJSON(res, status, body) {
  const payload = JSON.stringify(body, null, 2)
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" })
  res.end(payload)
}

async function readBody(req) {
  const chunks = []
  for await (const chunk of req) chunks.push(chunk)
  if (chunks.length === 0) return {}
  const raw = Buffer.concat(chunks).toString("utf8")
  if (raw.length > 1_000_000) throw new Error("request body too large")
  return JSON.parse(raw)
}

const PUBLIC_DIR = join(dirname(fileURLToPath(import.meta.url)), "..", "public")

/**
 * Minimal read/write API over the chain:
 *   GET  /chain                  full chain
 *   GET  /balance?address=0x..   balance of one address
 *   GET  /mempool                pending transactions
 *   POST /mine                   mine a block and broadcast it to this node
 */
export function createNode(port = 3000) {
  const server = createServer(async (req, res) => {
    const url = new URL(req.url, `http://localhost:${port}`)

    try {
      if (req.method === "GET" && url.pathname === "/") {
        const html = await readFile(join(PUBLIC_DIR, "index.html"))
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" })
        return res.end(html)
      }
      if (req.method === "GET" && ["/app.css", "/app.js"].includes(url.pathname)) {
        const name = url.pathname.slice(1)
        const content = await readFile(join(PUBLIC_DIR, name))
        res.writeHead(200, { "Content-Type": name.endsWith(".css") ? "text/css; charset=utf-8" : "text/javascript; charset=utf-8" })
        return res.end(content)
      }
      if (req.method === "GET" && url.pathname === "/api/overview") {
        const chain = Blockchain.load()
        const pool = loadMempool()
        const wallets = listWallets().map((wallet) => ({ address: wallet.address, balance: chain.getBalance(wallet.address) }))
        const transactions = chain.chain.slice(1).flatMap((block) => block.transactions.map((tx) => ({ ...tx.toJSON(), block: block.index }))).reverse()
        return sendJSON(res, 200, { height: chain.height - 1, difficulty: chain.difficulty, valid: chain.isValidChain(), fingerprint: chain.fingerprint(), wallets, mempool: pool.toJSON(), transactions, blocks: chain.chain.slice(1).map((block) => ({ ...block.toJSON(), transactionCount: block.transactions.length })).reverse() })
      }
      if (req.method === "POST" && url.pathname === "/api/wallets") {
        const wallet = new Wallet()
        saveWallet(wallet)
        return sendJSON(res, 201, { address: wallet.address })
      }
      if (req.method === "POST" && url.pathname === "/api/transactions") {
        const body = await readBody(req)
        if (typeof body.from !== "string" || typeof body.to !== "string") return sendJSON(res, 400, { error: "from and to are required" })
        const pool = loadMempool()
        const tx = loadWallet(body.from).createTransaction(body.to, Number(body.amount), pool)
        if (!pool.add(tx)) return sendJSON(res, 400, { error: "transaction rejected" })
        saveMempool(pool)
        return sendJSON(res, 201, { transaction: tx.toJSON() })
      }
      if (req.method === "POST" && url.pathname === "/api/mine") {
        const body = await readBody(req)
        const chain = Blockchain.load()
        const pool = loadMempool()
        const txs = pool.validTransactions(chain)
        const block = chain.mineBlock(txs, body.miner ?? null)
        Blockchain.save(chain)
        pool.clear()
        saveMempool(pool)
        return sendJSON(res, 200, { block: block.toJSON() })
      }
      if (req.method === "GET" && url.pathname === "/chain") {
        const chain = Blockchain.load()
        return sendJSON(res, 200, { height: chain.height, valid: chain.isValidChain(), chain: chain.toJSON().chain })
      }

      if (req.method === "GET" && url.pathname === "/balance") {
        const address = url.searchParams.get("address")
        if (!address) return sendJSON(res, 400, { error: "missing ?address=0x..." })
        return sendJSON(res, 200, { address, balance: Blockchain.load().getBalance(address) })
      }

      if (req.method === "GET" && url.pathname === "/mempool") {
        return sendJSON(res, 200, { mempool: loadMempool().toJSON() })
      }

      sendJSON(res, 404, { error: "not found" })
    } catch (error) {
      sendJSON(res, /wallet not found|insufficient funds|amount must|invalid recipient/.test(error?.message ?? "") ? 400 : 500, { error: String(error?.message ?? error) })
    }
  })

  server.listen(port, () => {
    console.log(`[minichain] node listening on http://localhost:${port}`)
  })
  return server
}
