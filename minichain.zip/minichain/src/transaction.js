import { sign, verify, hashJSON, addressFromPublicKey } from "./crypto.js"

/**
 * A signed value transfer. The signature covers every field in `payload()`,
 * and `from` is re-derived from the embedded public key, so neither the sender
 * nor the amount can be swapped after signing.
 */
export class Transaction {
  constructor({ from, to, amount, timestamp = Date.now(), publicKey = null, signature = null }) {
    this.from = from
    this.to = to
    this.amount = amount
    this.timestamp = timestamp
    this.publicKey = publicKey
    this.signature = signature
  }

  payload() {
    return { from: this.from, to: this.to, amount: this.amount, timestamp: this.timestamp, publicKey: this.publicKey }
  }

  /** Unique id used to reject replays of the same transfer. */
  get id() {
    return hashJSON(this.payload())
  }

  sign(wallet) {
    this.publicKey = wallet.publicKey
    this.from = wallet.address
    this.signature = sign(wallet.privateKey, hashJSON(this.payload()))
    return this
  }

  isValid() {
    if (typeof this.publicKey !== "string" || this.publicKey.length === 0) return false
    if (typeof this.from !== "string" || !/^0x[0-9a-f]{40}$/.test(this.from)) return false
    if (typeof this.to !== "string" || !/^0x[0-9a-f]{40}$/.test(this.to)) return false
    if (!Number.isInteger(this.amount) || this.amount <= 0) return false
    if (typeof this.signature !== "string" || this.signature.length === 0) return false
    if (this.from !== addressFromPublicKey(this.publicKey)) return false
    return verify(this.publicKey, hashJSON(this.payload()), this.signature)
  }

  toJSON() {
    return { ...this.payload(), signature: this.signature, coinbase: false }
  }

  static fromObject(obj) {
    return new Transaction(obj)
  }
}

/** Reward transaction minted by the block itself and paid to the miner. */
export class CoinbaseTransaction extends Transaction {
  constructor({ to, amount, height }) {
    super({ from: "0x0000000000000000000000000000000000000000", to, amount, timestamp: Date.now() })
    this.height = height
  }

  payload() {
    return { from: this.from, to: this.to, amount: this.amount, timestamp: this.timestamp, height: this.height }
  }

  isValid() {
    return /^0x[0-9a-f]{40}$/.test(this.to) && Number.isInteger(this.amount) && this.amount > 0
  }

  toJSON() {
    return { ...this.payload(), signature: null, coinbase: true }
  }

  static fromObject(obj) {
    const tx = new CoinbaseTransaction({ to: obj.to, amount: obj.amount, height: obj.height })
    tx.timestamp = obj.timestamp
    return tx
  }
}