#!/usr/bin/env node
import { Blockchain } from "./blockchain.js"
import { Mempool } from "./mempool.js"
import { Wallet } from "./wallet.js"
import "./store.js"

const HELP = `minichain - a blockchain from scratch, zero dependencies

Usage:
  minichain init                        reset the chain to the genesis block
  minichain wallet                      create a new wallet and print its address
  minichain wallets                     list saved wallets
  minichain balance <address>           show an address balance
  minichain mine [minerAddress]        mine the next block (default: no reward)
  minichain send <to> <amount>         sign a transfer from your wallet into the mempool
                                         add --from <address> to pick the paying wallet
  minichain mempool                     show pending transactions
  minichain chain                       print the chain
  minichain verify                      validate the whole chain
  minichain serve [port]                start the HTTP node (default port 3000)
`

const [, , command, ...args] = process.argv

function fail(message) {
  console.error(`error: ${message}`)
  process.exitCode = 1
}

async function main() {
  switch (command) {
    case "init": {
      const bc = Blockchain.reset()
      console.log(`chain reset, height = ${bc.height}`)
      break
    }

    case "wallet": {
      const wallet = new Wallet()
      const { saveWallet } = await import("./store.js")
      saveWallet(wallet)
      console.log(`new wallet: ${wallet.address}`)
      break
    }

    case "wallets": {
      const { listWallets } = await import("./store.js")
      const wallets = listWallets()
      if (wallets.length === 0) return console.log("no wallets yet, run: minichain wallet")
      for (const w of wallets) console.log(`${w.address}  balance=${Blockchain.load().getBalance(w.address)}`)
      break
    }

    case "balance": {
      const [address] = args
      if (!address) return fail("usage: minichain balance <address>")
      console.log(`balance ${Blockchain.load().getBalance(address)}`)
      break
    }

    case "mine": {
      const [miner] = args
      const chain = Blockchain.load()
      const { loadMempool, saveMempool } = await import("./store.js")
      const pool = loadMempool()
      const txs = pool.validTransactions(chain)
      const started = Date.now()
      const block = chain.mineBlock(txs, miner ?? null)
      Blockchain.save(chain)
      pool.clear()
      saveMempool(pool)
      console.log(`mined block #${block.index} in ${Date.now() - started}ms`)
      console.log(`hash        ${block.hash}`)
      console.log(`nonce       ${block.nonce}`)
      console.log(`merkle root ${block.merkleRoot()}`)
      console.log(`txs         ${block.transactions.length}`)
      break
    }

    case "send": {
      const positional = args.filter((a) => !a.startsWith("--"))
      const [to, amountRaw] = positional
      const fromFlagIndex = args.indexOf("--from")
      const amount = Number(amountRaw)
      if (!to || !Number.isInteger(amount)) return fail("usage: minichain send <to> <amount> [--from <address>]")

      const chain = Blockchain.load()
      const { listWallets, loadMempool, saveMempool } = await import("./store.js")
      const wallets = listWallets()
      if (wallets.length === 0) return fail("no wallet found, run: minichain wallet")

      const payer =
        fromFlagIndex >= 0 ? wallets.find((w) => w.address === args[fromFlagIndex + 1]) : null
      if (fromFlagIndex >= 0 && !payer) return fail(`no saved wallet with address ${args[fromFlagIndex + 1]}`)

      // Default to the funded wallet with the largest balance.
      const wallet =
        payer ??
        [...wallets].sort((a, b) => chain.getBalance(b.address) - chain.getBalance(a.address))[0]

      const pool = loadMempool()
      const tx = wallet.createTransaction(to, amount, pool)
      pool.add(tx)
      saveMempool(pool)
      console.log(`from    ${tx.from}`)
      console.log(`to      ${tx.to}`)
      console.log(`amount  ${tx.amount}`)
      console.log(`queued  ${tx.id}`)
      console.log(`mine it: minichain mine ${tx.from}`)
      break
    }

    case "mempool": {
      const { loadMempool } = await import("./store.js")
      const pool = loadMempool()
      console.log(JSON.stringify(pool.toJSON(), null, 2))
      break
    }

    case "chain": {
      const chain = Blockchain.load()
      console.log(JSON.stringify(chain.toJSON(), null, 2))
      break
    }

    case "verify": {
      const chain = Blockchain.load()
      const ok = chain.isValidChain()
      console.log(ok ? "chain is valid" : "chain is INVALID")
      process.exitCode = ok ? 0 : 1
      break
    }

    case "serve": {
      const { createNode } = await import("./server.js")
      createNode(Number(args[0]) || 3000)
      break
    }

    default:
      console.log(HELP)
  }
}

main().catch((error) => fail(error?.message ?? error))