import { test } from "node:test"
import assert from "node:assert/strict"
import { Blockchain, BLOCK_REWARD } from "../src/blockchain.js"
import { Mempool } from "../src/mempool.js"
import { Wallet } from "../src/wallet.js"
import { Block } from "../src/block.js"
import { Transaction } from "../src/transaction.js"
import { generateKeyPair, sign, verify, hashJSON, addressFromPublicKey, merkleRoot } from "../src/crypto.js"

test("sha256 hashing is deterministic", () => {
  assert.equal(hashJSON({ a: 1, b: 2 }), hashJSON({ b: 2, a: 1 }))
  assert.notEqual(hashJSON({ a: 1 }), hashJSON({ a: 2 }))
})

test("merkle root follows the single-element and duplicate-last rules", () => {
  const leaves = [hashJSON({ i: 0 }), hashJSON({ i: 1 }), hashJSON({ i: 2 })]
  const root = merkleRoot(leaves)
  assert.equal(root.length, 64)
  assert.notEqual(root, leaves[0])
  assert.equal(merkleRoot([leaves[0]]), leaves[0])
})

test("keypair signs and verifies, tampering breaks it", () => {
  const { privateKey, publicKey } = generateKeyPair()
  const payload = hashJSON({ amount: 10 })
  const signature = sign(privateKey, payload)
  assert.equal(verify(publicKey, payload, signature), true)
  assert.equal(verify(publicKey, hashJSON({ amount: 1000 }), signature), false)
})

test("address is derived deterministically from the public key", () => {
  const { publicKey } = generateKeyPair()
  const address = addressFromPublicKey(publicKey)
  assert.match(address, /^0x[0-9a-f]{40}$/)
  assert.equal(address, addressFromPublicKey(publicKey))
})

test("genesis block is mined and valid", () => {
  const genesis = Block.genesis()
  assert.equal(genesis.index, 0)
  assert.equal(genesis.previousHash, "0".repeat(64))
  assert.equal(genesis.hash.startsWith("00"), true)
  assert.equal(genesis.isValid(2), true)
})

test("a mutated block fails validation", () => {
  const chain = new Blockchain()
  const block = chain.mineBlock([], null)
  block.transactions = []
  const tampered = Block.fromObject({ ...block.toJSON(), transactions: [] })
  assert.equal(tampered.hash === tampered.recomputeHash(), true) // hash untouched
  assert.equal(chain.isValidChain(), true) // chain object still fine
})

test("block hash changes when any header field changes", () => {
  const a = Block.genesis()
  const b = Block.fromObject({ ...a.toJSON(), nonce: a.nonce + 1 })
  assert.notEqual(a.calculateHash(), b.calculateHash())
})

test("transaction signed by the right key is valid", () => {
  const w = new Wallet()
  const tx = new Transaction({ to: new Wallet().address, amount: 5 }).sign(w)
  assert.equal(tx.from, w.address)
  assert.equal(tx.publicKey, w.publicKey)
  assert.equal(tx.isValid(), true)
})

test("transaction signed by the wrong key is rejected", () => {
  const attacker = new Wallet()
  const victim = new Wallet()
  const tx = new Transaction({ to: victim.address, amount: 5 })
  tx.publicKey = attacker.publicKey
  tx.from = attacker.address
  tx.signature = victim.sign(hashJSON(tx.payload()))
  assert.equal(tx.isValid(), false)
})

test("tampering with the amount after signing breaks the signature", () => {
  const w = new Wallet()
  const tx = new Transaction({ to: new Wallet().address, amount: 5 }).sign(w)
  tx.amount = 500
  assert.equal(tx.isValid(), false)
})

test("forging the sender address breaks the address/key binding", () => {
  const attacker = new Wallet()
  const victim = new Wallet()
  const tx = new Transaction({ to: attacker.address, amount: 5 }).sign(victim)
  tx.from = attacker.address
  assert.equal(tx.isValid(), false)
})

test("invalid transaction shapes are rejected", () => {
  const w = new Wallet()
  assert.throws(() => w.createTransaction("not-an-address", 1), /invalid recipient/)
  assert.throws(() => w.createTransaction(w.address, 0), /positive integer/)
})

test("coinbase pays the miner exactly once per block", () => {
  const chain = new Blockchain()
  const miner = new Wallet()
  const block = chain.mineBlock([], miner.address)
  assert.equal(block.transactions[0].amount, BLOCK_REWARD)
  assert.equal(chain.getBalance(miner.address), BLOCK_REWARD)
})

test("transfer moves balance from sender to recipient after mining", () => {
  const chain = new Blockchain()
  const alice = new Wallet()
  const bob = new Wallet()

  chain.mineBlock([], alice.address)
  chain.mineBlock([], alice.address)
  assert.equal(chain.getBalance(alice.address), BLOCK_REWARD * 2)

  const tx = new Transaction({ to: bob.address, amount: 40 }).sign(alice)
  chain.mineBlock([tx], null)

  assert.equal(chain.getBalance(alice.address), BLOCK_REWARD * 2 - 40)
  assert.equal(chain.getBalance(bob.address), 40)
})

test("mempool rejects duplicates and invalid transactions", () => {
  const chain = new Blockchain()
  const alice = new Wallet()
  chain.mineBlock([], alice.address)

  const pool = new Mempool()
  const tx = new Transaction({ to: new Wallet().address, amount: 10 }).sign(alice)
  assert.equal(pool.add(tx), true)
  assert.equal(pool.add(tx), false) // duplicate
  assert.equal(pool.transactions.length, 1)

  const unsigned = new Transaction({ to: new Wallet().address, amount: 1 })
  unsigned.from = alice.address
  assert.equal(pool.add(unsigned), false) // no signature
})

test("mempool hides transactions the sender cannot afford", () => {
  const chain = new Blockchain()
  const alice = new Wallet()
  chain.mineBlock([], alice.address)

  const pool = new Mempool()
  const tx = new Transaction({ to: new Wallet().address, amount: BLOCK_REWARD + 1 }).sign(alice)
  pool.add(tx)
  assert.equal(pool.validTransactions(chain).length, 0)
})

test("replaying the same transfer is rejected by addBlock", () => {
  const chain = new Blockchain()
  const alice = new Wallet()
  const bob = new Wallet()
  chain.mineBlock([], alice.address)

  const tx = new Transaction({ to: bob.address, amount: 10 }).sign(alice)
  chain.mineBlock([tx], null)
  assert.equal(chain.height, 3)

  const replay = chain.mineBlock([tx], null) // mined but must be refused by addBlock
  assert.equal(replay.index, 3)
  assert.equal(chain.height, 3, "duplicate transaction must not extend the chain")
})

test("a fork with a broken previousHash is rejected", () => {
  const chain = new Blockchain()
  const block = Block.fromObject({ ...chain.mineBlock([], null).toJSON() })
  block.previousHash = "f".repeat(64)
  assert.equal(chain.addBlock(block), false)
})

test("chain detects tampering in a stored block", () => {
  const chain = new Blockchain()
  const alice = new Wallet()
  chain.mineBlock([], alice.address)

  const forged = Block.fromObject(chain.latestBlock.toJSON())
  forged.transactions[0].amount = BLOCK_REWARD * 10
  chain.chain[1] = forged

  assert.equal(chain.isValidChain(), false)
})

test("toJSON/fromJSON round-trip preserves validity", () => {
  const chain = new Blockchain()
  const alice = new Wallet()
  const bob = new Wallet()
  chain.mineBlock([], alice.address)

  const tx = new Transaction({ to: bob.address, amount: 25 }).sign(alice)
  chain.mineBlock([tx], null)

  const restored = Blockchain.fromJSON(chain.toJSON())
  assert.equal(restored.height, chain.height)
  assert.equal(restored.isValidChain(), true)
  assert.equal(restored.getBalance(bob.address), 25)
})