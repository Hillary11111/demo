const $ = (selector) => document.querySelector(selector)
let overview = null
let toastTimer

function short(value, start = 10, end = 7) {
  if (!value || value.length <= start + end + 3) return value ?? "—"
  return `${value.slice(0, start)}…${value.slice(-end)}`
}

function date(value) {
  return new Intl.DateTimeFormat("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false }).format(new Date(value))
}

function toast(message, error = false) {
  const el = $("#toast")
  el.textContent = message
  el.className = `toast show${error ? " error" : ""}`
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => { el.className = "toast" }, 3000)
}

async function api(path, options = {}) {
  const response = await fetch(path, { ...options, headers: { "Content-Type": "application/json", ...options.headers } })
  const body = await response.json()
  if (!response.ok) throw new Error(body.error ?? `Request failed (${response.status})`)
  return body
}

function render(data) {
  overview = data
  $("#height").textContent = data.height.toLocaleString()
  $("#pending").textContent = String(data.mempool.length).padStart(2, "0")
  $("#pending-note").textContent = data.mempool.length ? "等待打包确认" : "内存池为空"
  $("#difficulty").textContent = `${data.difficulty} 位`
  $("#health").textContent = data.valid ? "运行正常" : "校验失败"
  $("#health").style.color = data.valid ? "var(--green)" : "#ef8175"
  $("#fingerprint").textContent = `SHA-256 · ${short(data.fingerprint, 8, 6)}`
  $("#block-count").textContent = `${data.blocks.length} BLOCK${data.blocks.length === 1 ? "" : "S"}`
  $("#updated").textContent = `更新于 ${new Date().toLocaleTimeString("zh-CN", { hour12: false })}`

  $("#blocks").innerHTML = data.blocks.length ? data.blocks.slice(0, 6).map((block) => `<tr><td class="mono">#${block.index}</td><td class="mono hash" title="${block.hash}">${short(block.hash, 16, 8)}</td><td class="mono">${block.transactionCount}</td><td class="mono">${date(block.timestamp)}</td><td class="mono">${Number(block.nonce).toLocaleString()}</td></tr>`).join("") : `<tr><td colspan="5" class="empty">创世区块已就绪，挖掘新区块以开始记账</td></tr>`

  $("#transactions").innerHTML = data.transactions.length ? data.transactions.slice(0, 6).map((tx) => `<tr><td class="mono hash" title="${tx.signature ?? tx.timestamp}">${short(tx.signature ? tx.from : tx.to, 13, 6)}</td><td><span class="tx-direction"><i class="tx-dot ${tx.from === "0x0000000000000000000000000000000000000000" ? "in" : ""}"></i>${tx.from === "0x0000000000000000000000000000000000000000" ? "挖矿奖励" : "链上转账"}</span></td><td class="amount">+${tx.amount} MCH</td><td class="mono">#${tx.block}</td><td><span class="badge">已确认</span></td></tr>`).join("") : `<tr><td colspan="5" class="empty">暂无已确认交易</td></tr>`

  $("#wallet-list").innerHTML = data.wallets.length ? data.wallets.map((wallet, index) => `<div class="wallet-row"><div class="wallet-label"><span class="wallet-mark">◇</span><span class="wallet-address" title="${wallet.address}">${short(wallet.address, 15, 9)}</span></div><span class="wallet-balance">${wallet.balance.toLocaleString()} MCH</span><span class="wallet-unit">WALLET ${String(index + 1).padStart(2, "0")}</span></div>`).join("") : `<div class="empty">创建钱包开始使用链上功能</div>`

  const from = $("#from-wallet")
  const current = from.value
  from.innerHTML = data.wallets.map((wallet) => `<option value="${wallet.address}">${short(wallet.address, 12, 6)} · ${wallet.balance} MCH</option>`).join("")
  if (data.wallets.some((wallet) => wallet.address === current)) from.value = current
  $("#miner-wallet").innerHTML = `<option value="">不领取奖励</option>${data.wallets.map((wallet) => `<option value="${wallet.address}">${short(wallet.address, 12, 6)}</option>`).join("")}`
  $("#mine-summary-text").textContent = `${data.mempool.length} 笔待处理交易将被打包。${data.wallets.length ? "挖矿奖励为 50 MCH。" : "创建钱包后可领取挖矿奖励。"}`
}

async function refresh() {
  const button = $("#refresh")
  button.classList.add("busy")
  try { render(await api("/api/overview")) } catch (error) { toast(`无法连接节点：${error.message}`, true) }
  finally { button.classList.remove("busy") }
}

$("#refresh").addEventListener("click", refresh)
$("#open-send").addEventListener("click", () => {
  if (!overview?.wallets.length) return toast("请先创建一个钱包。", true)
  $("#send-dialog").showModal()
})
$("#open-mine").addEventListener("click", () => $("#mine-dialog").showModal())

$("#new-wallet").addEventListener("click", async (event) => {
  const button = event.currentTarget
  button.disabled = true
  try {
    const result = await api("/api/wallets", { method: "POST", body: "{}" })
    await refresh()
    toast(`钱包已创建：${short(result.address, 12, 8)}`)
  } catch (error) { toast(error.message, true) }
  finally { button.disabled = false }
})

$("#send-form").addEventListener("submit", async (event) => {
  if (event.submitter?.value === "cancel") return
  event.preventDefault()
  const errorMessage = $("#send-error")
  errorMessage.hidden = true
  const button = $("#submit-send")
  button.disabled = true
  try {
    await api("/api/transactions", { method: "POST", body: JSON.stringify({ from: $("#from-wallet").value, to: $("#recipient").value.trim(), amount: Number($("#amount").value) }) })
    $("#send-dialog").close()
    $("#recipient").value = ""
    $("#amount").value = ""
    await refresh()
    toast("交易已签名并加入待处理队列。")
  } catch (error) {
    errorMessage.textContent = error.message
    errorMessage.hidden = false
  }
  finally { button.disabled = false }
})

$("#mine-form").addEventListener("submit", async (event) => {
  if (event.submitter?.value === "cancel") return
  event.preventDefault()
  const button = $("#submit-mine")
  button.disabled = true
  button.textContent = "计算工作量证明…"
  try {
    const result = await api("/api/mine", { method: "POST", body: JSON.stringify({ miner: $("#miner-wallet").value || null }) })
    $("#mine-dialog").close()
    await refresh()
    toast(`区块 #${result.block.index} 已成功挖出。`)
  } catch (error) { toast(error.message, true) }
  finally { button.disabled = false; button.textContent = "开始挖矿 ⛏" }
})

refresh()
setInterval(refresh, 15000)
